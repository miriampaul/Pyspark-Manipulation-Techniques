# Databricks notebook source
data = [
    (1, "Sagar", 34, "IT"),
    (1, "Sagar", 45, "IT"),
    (2, "Kim", 39, "IT"),
    (2, "Kim", 40, "Maths"),
    (3, "John", 50, "Science"),
]
schema = "ID int,Name string,Marks int, Sub string"
df = spark.createDataFrame(data, schema)
display(df)

# COMMAND ----------


df_final=df.groupBy("ID","Name","SUB").count()
display(df_final)

# COMMAND ----------

from pyspark.sql.functions import col,collect_list,collect_set,sum
df_final=df.groupBy(col("ID"),col("Name")).agg(collect_list(col("Sub")).alias("subjects"),sum("marks").alias("marks"))
df_final.show()

# COMMAND ----------

from pyspark.sql.functions import col,collect_list,collect_set,sum
df_final=df.groupBy(col("ID"),col("Name")).agg(collect_set(col("Sub")).alias("subjects"),sum("marks").alias("marks"))
df_final.show()