# Databricks notebook source
data=[(1,'Sagar',34,'IT'),(1,'Sagar',45,'Maths'),(2,'Kim',39,'IT'),(2,'Kim',40,'Maths'),(3,'John',50,'Science')]
schema="ID int,Name string,Marks int, Sub string"
df=spark.createDataFrame(data,schema)
display(df)

# COMMAND ----------

-- max ,, min ,, avg, sum ,mean,count

# COMMAND ----------

from pyspark.sql.functions import sum,count,countDistinct,col
df.groupBy("ID","Name").agg(sum("Marks").alias("marks")).filter(col("marks")>50).orderBy("marks","Name").show()