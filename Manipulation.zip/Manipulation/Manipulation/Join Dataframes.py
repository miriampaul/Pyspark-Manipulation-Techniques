# Databricks notebook source
df_1=spark.createDataFrame(data=[(1,'sagar'),(2,'Alex'),(4,'John')],schema="ID int, Name string")
df_2=spark.createDataFrame(data=[(1,23),(2,45),(3,56)],schema="ID int, Age int")

# COMMAND ----------

inner join
left join
right join
cross join
full join

# COMMAND ----------

display(df_1)
display(df_2)

# COMMAND ----------

from pyspark.sql.functions import col
df_final=df_1.join(df_2,df_1.ID==df_2.ID,"left").select(df_1.ID,df_2.Age).filter(col("Age")>20)
display(df_final)

# COMMAND ----------

df_final=df_1.join(df_2,df_1.ID==df_2.ID,"full")
display(df_final)

# COMMAND ----------

df_final=df_1.crossJoin(df_2)
display(df_final)