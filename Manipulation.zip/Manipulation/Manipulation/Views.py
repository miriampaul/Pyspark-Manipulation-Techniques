# Databricks notebook source
df=spark.createDataFrame(data=[(1,'sagar'),(2,'Shivam')],schema="ID int,Name string")
df.show()

# COMMAND ----------

df.createGlobalTempView
df.createOrReplaceGlobalTempView
df.createOrReplaceTempView
df.createTempView

# COMMAND ----------

df.createGlobalTempView("df_test")

# COMMAND ----------

df.createOrReplaceGlobalTempView("df_test")

# COMMAND ----------

df.createOrReplaceTempView("df_test_temp")

# COMMAND ----------

df_1=spark.read.table('global_temp.df_test')
display(df_1)