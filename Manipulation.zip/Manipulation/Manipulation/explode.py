# Databricks notebook source
data = [
    (1, "Sagar", 34, "IT"),
    (1, "Sagar", 45, "IT"),
    (2, "Kim", 39, "IT"),
    (2, "Kim", 40, "Maths"),
    (3, "John", 50, "Science"),
]
schema = "ID int,Name string,Marks int, Sub string"
df = spark.createDataFrame(data, schema)
display(df)

# COMMAND ----------

from pyspark.sql.functions import col,collect_list,collect_set,sum
df_final=df.groupBy(col("ID"),col("Name")).agg(collect_list(col("Sub")).alias("subjects"),sum("marks").alias("marks"))
df_final.show()

# COMMAND ----------

data = [
    (1, None,["IT",None]),
  
    (2, "Kim",["IT","Maths"]),
    (3, "John",["Science"]),
]
schema = "ID int,Name string,Sub array<string>"
df = spark.createDataFrame(data, schema)
display(df)

# COMMAND ----------

from pyspark.sql.functions import explode,col,expr

# COMMAND ----------

df_final=df.select("ID","Name",explode("Sub").alias("sub"))
df_final.show()