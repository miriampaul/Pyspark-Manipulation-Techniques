# Databricks notebook source
df=spark.read.format('csv').option('header',True).option('inferschema',True).load('/FileStore/tables/datafile/raw_data.csv')

# COMMAND ----------

df.show()

# COMMAND ----------

df=df.drop(*['DOB','Age'])

# COMMAND ----------

display(df)

# COMMAND ----------

df=df.select("ID","Name")

# COMMAND ----------

df.show()

# COMMAND ----------

data=[(1,'Sagar'),(2,'Kim'),(3,'Sagar')]
schema="ID int, Name string"
df=spark.createDataFrame(data,schema)
display(df)

# COMMAND ----------

df.dropDuplicates("*").show()

# COMMAND ----------

display(df)