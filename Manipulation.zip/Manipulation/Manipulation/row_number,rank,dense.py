# Databricks notebook source
data = [(1, "sagar"), (1, "sagar"), (1, "pagar"),(1, "pagar"),(1, "ragar") ,(2, "Kim"), (3, "John"), (3, "kohny")]
schema = "ID int,Name string"
df = spark.createDataFrame(data, schema)
display(df)

# COMMAND ----------

--row_number
--rank
-- dense_rank

# COMMAND ----------

from pyspark.sql.functions import row_number,rank,dense_rank,col
from pyspark.sql.window import Window
window_spec=Window.partitionBy(col("ID"),col("Name")).orderBy(col("Name").desc())
df_final=df.withColumn("rn",row_number().over(window_spec))
display(df_final)

# COMMAND ----------

from pyspark.sql.functions import row_number,rank,dense_rank,col
from pyspark.sql.window import Window
window_spec=Window.partitionBy(col("ID")).orderBy(col("Name").desc())
df_final=df.withColumn("rn",rank().over(window_spec))
display(df_final)

# COMMAND ----------

from pyspark.sql.functions import row_number,rank,dense_rank,col
from pyspark.sql.window import Window
window_spec=Window.partitionBy(col("ID")).orderBy(col("Name").desc())
df_final=df.withColumn("rn",dense_rank().over(window_spec))
display(df_final)