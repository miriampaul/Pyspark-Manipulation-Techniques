# Databricks notebook source
df=spark.read.format('csv').option('header',True).option('inferschema',True).load('/FileStore/tables/datafile/raw_data.csv')

# COMMAND ----------

df.show()

# COMMAND ----------

from pyspark.sql.functions import *
df.orderBy(col("Name").desc(),col("ID").desc()).show()