# Databricks notebook source
df=spark.read.format('csv').option('header',True).option('inferschema',True).load('/FileStore/tables/datafile/raw_data.csv')

# COMMAND ----------

df.write.mode('overwrite').saveAsTable('db.test1')

# COMMAND ----------

# MAGIC %sql
# MAGIC desc extended db.test1

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table db.test1

# COMMAND ----------

dbutils.fs.ls('dbfs:/user/hive/warehouse/db.db/test1')

# COMMAND ----------

df=spark.read.format('csv').option('header',True).option('inferschema',True).load('/FileStore/tables/datafile/raw_data.csv')

# COMMAND ----------

# MAGIC %sql
# MAGIC desc db.test2

# COMMAND ----------

df.write.mode('overwrite').option('path','/FileStore/tables/external/output/test3').saveAsTable('db.test3')

# COMMAND ----------

# MAGIC %sql
# MAGIC desc extended db.test3

# COMMAND ----------

df.write.mode('overwrite').saveAsTable('db.test2')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from db.test2

# COMMAND ----------

# MAGIC %sql
# MAGIC create external table db.test4
# MAGIC (
# MAGIC
# MAGIC    ID int,
# MAGIC    Name string,
# MAGIC    Age int,
# MAGIC    DOB date
# MAGIC )
# MAGIC location '/FileStore/tables/external/output/test4'

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from delta.`/FileStore/tables/external/output/test2`

# COMMAND ----------

dbutils.fs.rm('/FileStore/tables/external/output/test2',True)

# COMMAND ----------

# MAGIC %sql
# MAGIC desc extended db.test2