# Databricks notebook source
df=spark.read.format('csv').option('header',True).option('inferschema',True).load('/FileStore/tables/datafile/raw_data.csv')

# COMMAND ----------

df.show()

# COMMAND ----------

from pyspark.sql.functions import lit,col
df.withColumn("flag",lit("1")).show()

# COMMAND ----------

df.withColumn("ID_New",col("ID")+1).show()

# COMMAND ----------

df.withColumn("ID_New", col("ID") + 1).withColumn("flag", lit(1)).show()

# COMMAND ----------

df.withColumns({"ID_New":col("ID")+1,"flag":lit(2)}).show()