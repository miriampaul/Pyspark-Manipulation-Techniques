# Databricks notebook source
df=spark.read.format('csv').option('header',True).option('inferschema',True).load('/FileStore/tables/datafile/raw_data.csv')

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import when,lit,col

# COMMAND ----------

df.withColumn(
    "voting",
    when(((col("Age") > 22) & (col("ID") > 3)), lit("Eligible")).otherwise(
        "Not eligible"
    ),
).show()

# COMMAND ----------

df.selectExpr("*","case when age>22 and id>3 then 'eligible' else 'not eligible' end as voting").show()