# Databricks notebook source
data=[(1,'Sagar',34),(2,None,35),(None,'Kim',None)]
schema="ID int,Name string,Age int"
df=spark.createDataFrame(data,schema)
display(df)

# COMMAND ----------

df.na.fill(0,['ID']).na.fill(999,['Age']).show()

# COMMAND ----------

df.na.fill({'ID':0,'Age':999}).show()

# COMMAND ----------

df.fillna(True).show()