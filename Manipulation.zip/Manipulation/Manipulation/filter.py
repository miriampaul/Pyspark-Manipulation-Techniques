# Databricks notebook source
df=spark.read.format('csv').option('header',True).option('inferschema',True).load('/FileStore/tables/datafile/raw_data.csv')

# COMMAND ----------

df.show()

# COMMAND ----------

from pyspark.sql.functions import col,lower
df.filter(col("Age")>22).show()

# COMMAND ----------

df.filter((col("Name")).rlike(r'^[sS]')).show()

# COMMAND ----------

df.filter((col("Name")).like('A%')).show()

# COMMAND ----------

from pyspark.sql.functions import col,lower
df.filter(((col("Age")>22) & (col("Name")=='Sagar'))).show()

# COMMAND ----------

"""
& --and
| --or 
~ not
"""

# COMMAND ----------

from pyspark.sql.functions import col,lower
df.where(col("Age")>22).show()

# COMMAND ----------

list_name=['Sagar','Alex']
df.filter(~(col("Name")).isin(list_name)).show()