# Databricks notebook source
df=spark.read.format('csv').option('header',True).option('inferschema',True).load('/FileStore/tables/datafile/raw_data.csv')

# COMMAND ----------

df.show()

# COMMAND ----------

df.withColumnsRenamed({"ID":"ID_New","Name":"First_Name"}).show()

# COMMAND ----------

display(df)

# COMMAND ----------

from pyspark.sql.functions import col
df.select(col("ID").alias("ID_New"),"*").drop("ID").show()

# COMMAND ----------

from pyspark.sql.functions import col
df.selectExpr("ID AS ID_New","*").show()