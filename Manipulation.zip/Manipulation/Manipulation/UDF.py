# Databricks notebook source
from pyspark.sql.functions import col,lit

# COMMAND ----------

data=[(1,"sagar"),(2,"kim")]
schema="ID int, Name string"
df=spark.createDataFrame(data,schema)
display(df)

# COMMAND ----------

from pyspark.sql.types import StringType
#@udf(returnType=StringType())
def f_add_constant3(input_string:str):
    return input_string+" abc"

# COMMAND ----------

from pyspark.sql.functions import udf
f_add_constant1=udf(lambda x:f_add_constant3(x),StringType())

# COMMAND ----------

df.withColumn("new_col",f_add_constant1(col("Name"))).show()