# Databricks notebook source
df=spark.read.format('csv').option('header',True).option('inferschema',True).load('/FileStore/tables/datafile/raw_data.csv')

# COMMAND ----------

df.show()

# COMMAND ----------

display(df)

# COMMAND ----------

df.select("ID","Name").show()

# COMMAND ----------

from pyspark.sql.functions import col

# COMMAND ----------

df.select(col("ID"),col("Name")).show()

# COMMAND ----------

df.select(df.ID,df.Name).show()

# COMMAND ----------

df.select(df['ID'],df['Name']).show()

# COMMAND ----------

df.select(df.columns[:-2]).show()

# COMMAND ----------

df.select([i for i in df.columns]).show()

# COMMAND ----------

data = [
        (("Sagar","Prajapati"),"UP","M"),
        (("Alex","G"),"NY","F"),
        (("Kim","Williams"),"OH","F")
        ]

from pyspark.sql.types import StructType,StructField, StringType        
schema = StructType([
    StructField('name', StructType([
         StructField('firstname', StringType(), True),
         StructField('lastname', StringType(), True)
         ])),
     StructField('state', StringType(), True),
     StructField('gender', StringType(), True)
     ])
df2 = spark.createDataFrame(data = data, schema = schema)
df2.printSchema()
df2.show(truncate=False)

# COMMAND ----------

df2.select(df2.name.firstname).show()

# COMMAND ----------

df2.select("name.*").show()

# COMMAND ----------

df.show()

# COMMAND ----------

df.selectExpr("ID","Name").show()