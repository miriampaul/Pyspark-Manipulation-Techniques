# Databricks notebook source
df=spark.read.format('csv').option('header',True).option('inferschema',True).load('/FileStore/tables/datafile/raw_data.csv')

# COMMAND ----------

df.show()

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,current_date
df1=df.withColumn("current_date",current_date())
df1.show()

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,current_date
df1=df.withColumn("current_timestamp",current_timestamp())
df1.show()

# COMMAND ----------

from pyspark.sql.functions import current_timestamp,current_date,col,year,day,month
df1=df.withColumn("year",year(col('DOB'))).withColumn("month",month(col('DOB'))).withColumn("day",day(col('DOB')))
df1.show()

# COMMAND ----------

data=[(1,'2023-01-01'),(2,'2024-02-24')]
schema="ID int, date string"
df3=spark.createDataFrame(data,schema)
df3.show()

# COMMAND ----------

from pyspark.sql.functions import to_date
df2=df3.withColumn("date1",to_date(col('date'),'yyyy-MM-dd'))
df2.show()

# COMMAND ----------

from pyspark.sql.functions import to_date,date_format
df2=df3.withColumn("date1",date_format(col('date'),format='yyyy-MMM-dd'))
df2.show()