# Databricks notebook source
df=spark.read.format('csv').option('header',True).option('inferschema',True).load('/FileStore/tables/datafile/raw_data.csv')

# COMMAND ----------

df.show()

# COMMAND ----------

# MAGIC %sql
# MAGIC create database db

# COMMAND ----------

mode 

-- overwrite
-- append
-- ignore
-- error

# COMMAND ----------

df.write.format('csv').option('sep','|').mode('error').saveAsTable('db.raw_data_output')

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from db.raw_data_output

# COMMAND ----------

# MAGIC %sql
# MAGIC desc db.raw_data_output

# COMMAND ----------

# MAGIC %sql
# MAGIC desc extended db.raw_data_output

# COMMAND ----------

df.write.format('csv').option('sep','|').mode('overwrite').save('/FileStore/tables/output/raw_data')

# COMMAND ----------

dbutils.fs.ls('/FileStore/tables/output/raw_data')

# COMMAND ----------

data=[(1,'Sagar','IT'),(2,'Kim','IT'),(1,'Sagar','Science'),(1,'Sagar','Math'),(2,'Kim','Science'),(1,'Sagar','IT'),(1,'Sagar','IT'),(3,'John','Science')]
schema="ID int,Name string,dept string"
df=spark.createDataFrame(data,schema)

# COMMAND ----------

df.show()

# COMMAND ----------

df.write.partitionBy('dept','ID').format('parquet').mode('overwrite').save('/FileStore/tables/output/raw_data')

# COMMAND ----------

dbutils.fs.ls('/FileStore/tables/output/raw_data/dept=IT')

# COMMAND ----------

# MAGIC %sql
# MAGIC select  * from parquet.`dbfs:/FileStore/tables/output/raw_data/`